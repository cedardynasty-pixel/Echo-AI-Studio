# Echo AI Studio

A small YouTube-style app: a public home feed, a vertical Shorts feed, and an
admin area where you and a co-admin can upload videos and shorts.

**Stack:** Next.js 14 (App Router) · Postgres via Prisma · Cloudinary for video
storage/streaming · NextAuth (credentials) for admin login. This split matters
on Vercel specifically: Vercel's serverless functions have no persistent disk
and a small request body limit, so video files are uploaded directly from the
browser to Cloudinary — they never pass through your Vercel functions.

## 1. Install dependencies

```bash
npm install
```

## 2. Set up a database

Create a free Postgres database — [Neon](https://neon.tech) or
[Vercel Postgres](https://vercel.com/storage/postgres) both work. Copy the
connection string.

Copy `.env.example` to `.env` and fill in `DATABASE_URL`, then push the schema:

```bash
cp .env.example .env
npx prisma db push
```

## 3. Set up Cloudinary

Create a free account at [cloudinary.com](https://cloudinary.com). From the
dashboard, copy your **Cloud name**, **API Key**, and **API Secret** into
`.env`:

```
CLOUDINARY_CLOUD_NAME=...
CLOUDINARY_API_KEY=...
CLOUDINARY_API_SECRET=...
NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME=...   # same value as CLOUDINARY_CLOUD_NAME
```

No upload preset needed — uploads are signed server-side.

## 4. Create your admin accounts

Set `ADMIN_EMAIL` / `ADMIN_PASSWORD` (and optionally `ADMIN_NAME`) in `.env`,
then run:

```bash
npm run create-admin
```

Run it again with different values to create your co-admin's account (their
own `.env` values, or pass them inline:
`ADMIN_EMAIL=cohost@example.com ADMIN_PASSWORD=... npm run create-admin`).

Also set `NEXTAUTH_SECRET` in `.env` — generate one with:

```bash
openssl rand -base64 32
```

## 5. Run it locally

```bash
npm run dev
```

Visit `http://localhost:3000`, and `http://localhost:3000/login` to sign in
as an admin, then `/admin/upload` to publish something.

## 6. Deploy to Vercel

1. Push this project to a GitHub repo.
2. Import the repo in [Vercel](https://vercel.com/new).
3. Add the same environment variables from `.env` in the Vercel project
   settings (Settings → Environment Variables) — `DATABASE_URL`,
   `NEXTAUTH_SECRET`, `NEXTAUTH_URL` (your production URL, e.g.
   `https://your-app.vercel.app`), `CLOUDINARY_CLOUD_NAME`,
   `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET`,
   `NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME`.
4. Deploy. Then run `npm run create-admin` once from your own machine
   pointed at the production `DATABASE_URL` (or temporarily set
   `ADMIN_EMAIL`/`ADMIN_PASSWORD` as Vercel env vars and hit a one-off route —
   the local script is simplest).

## How admin access works

There's no public sign-up. Only accounts created with `npm run create-admin`
can sign in at `/login`, and only signed-in accounts can upload or delete
content — the home page and Shorts feed are public to everyone else.

## Project layout

```
src/app/            pages (home, shorts, watch/[id], admin, login) + API routes
src/components/      Navbar, VideoGrid/VideoCard, ShortsPlayer, UploadForm
src/lib/             prisma client, NextAuth config, Cloudinary signing
prisma/schema.prisma User and Video models
scripts/create-admin.js   creates/updates an admin login
```

## Extending it

- **Comments / likes:** add a `Comment` model to `prisma/schema.prisma`,
  `npx prisma db push`, then a small API route + form.
- **Multiple admins with different roles:** the `role` field on `User` is
  already there — check it in the API routes if you want e.g. an editor role
  that can't delete.
- **Custom domain:** set it up in Vercel, then update `NEXTAUTH_URL`.
