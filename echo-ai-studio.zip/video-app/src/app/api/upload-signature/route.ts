import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { buildUploadSignature } from "@/lib/cloudinary";

// Admin-only: hands the browser a short-lived signature so it can upload the
// video file directly to Cloudinary without it passing through our server.
export async function POST() {
  const session = await auth();
  if (!session) {
    return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  }

  const timestamp = Math.floor(Date.now() / 1000);
  const folder = "echo-ai-studio";
  const signature = buildUploadSignature({ timestamp, folder });

  return NextResponse.json({
    timestamp,
    folder,
    signature,
    apiKey: process.env.CLOUDINARY_API_KEY,
    cloudName: process.env.CLOUDINARY_CLOUD_NAME
  });
}
