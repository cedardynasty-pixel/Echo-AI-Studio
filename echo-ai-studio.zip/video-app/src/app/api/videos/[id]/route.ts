import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { destroyCloudinaryAsset } from "@/lib/cloudinary";

// GET a single video and bump its view count
export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const video = await prisma.video.update({
    where: { id: params.id },
    data: { views: { increment: 1 } },
    include: { author: { select: { name: true, email: true } } }
  }).catch(() => null);

  if (!video) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json(video);
}

// DELETE — admin only, also removes the file from Cloudinary
export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  }

  const video = await prisma.video.findUnique({ where: { id: params.id } });
  if (!video) return NextResponse.json({ error: "Not found" }, { status: 404 });

  await destroyCloudinaryAsset(video.publicId);
  await prisma.video.delete({ where: { id: params.id } });

  return NextResponse.json({ ok: true });
}
