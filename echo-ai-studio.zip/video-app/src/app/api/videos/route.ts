import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

// GET /api/videos?type=video|short  — public, powers the home page and shorts feed
export async function GET(req: NextRequest) {
  const type = req.nextUrl.searchParams.get("type");

  const videos = await prisma.video.findMany({
    where: type ? { type } : undefined,
    orderBy: { createdAt: "desc" },
    include: { author: { select: { name: true, email: true } } }
  });

  return NextResponse.json(videos);
}

// POST /api/videos — admin only, saves metadata for a file already uploaded to Cloudinary
export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  }

  const body = await req.json();
  const { title, description, type, videoUrl, thumbnailUrl, publicId, duration } = body;

  if (!title || !videoUrl || !publicId || !type) {
    return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
  }
  if (type !== "video" && type !== "short") {
    return NextResponse.json({ error: "type must be 'video' or 'short'" }, { status: 400 });
  }

  const video = await prisma.video.create({
    data: {
      title,
      description: description || null,
      type,
      videoUrl,
      thumbnailUrl: thumbnailUrl || null,
      publicId,
      duration: duration ?? null,
      authorId: (session.user as { id: string }).id
    }
  });

  return NextResponse.json(video, { status: 201 });
}
