import UploadForm from "@/components/UploadForm";

export default function UploadPage() {
  return (
    <div>
      <h1 className="font-display text-2xl font-semibold text-ink">Upload</h1>
      <p className="mt-1 text-sm text-mute">Add a new video or a short.</p>
      <div className="mt-6">
        <UploadForm />
      </div>
    </div>
  );
}
