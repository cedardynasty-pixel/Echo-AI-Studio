import Link from "next/link";
import { prisma } from "@/lib/prisma";
import DeleteVideoButton from "@/components/DeleteVideoButton";

export const dynamic = "force-dynamic";

export default async function AdminDashboard() {
  const videos = await prisma.video.findMany({
    orderBy: { createdAt: "desc" },
    include: { author: { select: { name: true, email: true } } }
  });

  return (
    <div>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-semibold text-ink">Admin dashboard</h1>
          <p className="mt-1 text-sm text-mute">{videos.length} item{videos.length === 1 ? "" : "s"} published</p>
        </div>
        <Link
          href="/admin/upload"
          className="rounded-lg bg-accent px-4 py-2 font-medium text-white hover:opacity-90"
        >
          Upload
        </Link>
      </div>

      <div className="mt-6 divide-y divide-line rounded-xl border border-line">
        {videos.length === 0 && (
          <p className="p-6 text-sm text-mute">Nothing uploaded yet.</p>
        )}
        {videos.map((video) => (
          <div key={video.id} className="flex items-center gap-4 p-4">
            <div className="h-16 w-28 flex-shrink-0 overflow-hidden rounded-lg bg-panel">
              {video.thumbnailUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={video.thumbnailUrl} alt="" className="h-full w-full object-cover" />
              ) : (
                <video src={video.videoUrl} className="h-full w-full object-cover" muted />
              )}
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate font-medium text-ink">{video.title}</p>
              <p className="text-sm text-mute">
                {video.type === "short" ? "Short" : "Video"} · {video.views} views · {video.author.name ?? video.author.email}
              </p>
            </div>
            <Link href={`/watch/${video.id}`} className="text-sm text-mute hover:text-ink">
              View
            </Link>
            <DeleteVideoButton id={video.id} />
          </div>
        ))}
      </div>
    </div>
  );
}
