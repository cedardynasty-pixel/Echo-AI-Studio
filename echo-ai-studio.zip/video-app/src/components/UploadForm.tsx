"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

type CloudinarySignature = {
  timestamp: number;
  folder: string;
  signature: string;
  apiKey: string;
  cloudName: string;
};

function uploadToCloudinary(file: File, sig: CloudinarySignature, onProgress: (pct: number) => void) {
  return new Promise<{ secure_url: string; public_id: string; duration?: number }>((resolve, reject) => {
    const formData = new FormData();
    formData.append("file", file);
    formData.append("api_key", sig.apiKey);
    formData.append("timestamp", String(sig.timestamp));
    formData.append("signature", sig.signature);
    formData.append("folder", sig.folder);

    const xhr = new XMLHttpRequest();
    xhr.open("POST", `https://api.cloudinary.com/v1_1/${sig.cloudName}/video/upload`);

    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable) onProgress(Math.round((event.loaded / event.total) * 100));
    };
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) resolve(JSON.parse(xhr.responseText));
      else reject(new Error("Cloudinary upload failed"));
    };
    xhr.onerror = () => reject(new Error("Network error during upload"));
    xhr.send(formData);
  });
}

export default function UploadForm() {
  const router = useRouter();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [type, setType] = useState<"video" | "short">("video");
  const [file, setFile] = useState<File | null>(null);
  const [progress, setProgress] = useState(0);
  const [stage, setStage] = useState<"idle" | "uploading" | "saving" | "done">("idle");
  const [error, setError] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");

    if (!file) {
      setError("Choose a video file first.");
      return;
    }

    try {
      setStage("uploading");
      setProgress(0);

      const sigRes = await fetch("/api/upload-signature", { method: "POST" });
      if (!sigRes.ok) throw new Error("Could not start the upload. Are you signed in?");
      const sig: CloudinarySignature = await sigRes.json();

      const uploaded = await uploadToCloudinary(file, sig, setProgress);
      const thumbnailUrl = uploaded.secure_url.replace(/\.[^/.]+$/, ".jpg");

      setStage("saving");
      const saveRes = await fetch("/api/videos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          description,
          type,
          videoUrl: uploaded.secure_url,
          thumbnailUrl,
          publicId: uploaded.public_id,
          duration: uploaded.duration ? Math.round(uploaded.duration) : null
        })
      });
      if (!saveRes.ok) throw new Error("Upload succeeded but saving details failed.");

      setStage("done");
      router.push("/admin");
      router.refresh();
    } catch (err) {
      setStage("idle");
      setError(err instanceof Error ? err.message : "Something went wrong.");
    }
  }

  const busy = stage === "uploading" || stage === "saving";

  return (
    <form onSubmit={handleSubmit} className="flex max-w-xl flex-col gap-4">
      <div className="flex gap-2">
        {(["video", "short"] as const).map((option) => (
          <button
            key={option}
            type="button"
            onClick={() => setType(option)}
            className={`rounded-full px-4 py-1.5 text-sm capitalize transition-colors ${
              type === option ? "bg-accent text-white" : "border border-line text-mute hover:text-ink"
            }`}
          >
            {option === "video" ? "Video" : "Short"}
          </button>
        ))}
      </div>

      <label className="flex flex-col gap-1.5">
        <span className="text-sm text-mute">Title</span>
        <input
          required
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="rounded-lg border border-line bg-panel px-3 py-2 text-ink outline-none focus:border-accent"
          placeholder="Give it a clear, specific title"
        />
      </label>

      <label className="flex flex-col gap-1.5">
        <span className="text-sm text-mute">Description (optional)</span>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={4}
          className="rounded-lg border border-line bg-panel px-3 py-2 text-ink outline-none focus:border-accent"
          placeholder="What is this about?"
        />
      </label>

      <label className="flex flex-col gap-1.5">
        <span className="text-sm text-mute">Video file</span>
        <input
          required
          type="file"
          accept="video/*"
          onChange={(e) => setFile(e.target.files?.[0] ?? null)}
          className="rounded-lg border border-dashed border-line bg-panel px-3 py-6 text-sm text-mute file:mr-3 file:rounded-full file:border-0 file:bg-accent file:px-3 file:py-1.5 file:text-white"
        />
        {type === "short" && (
          <span className="text-xs text-mute">Vertical, under a minute works best for shorts.</span>
        )}
      </label>

      {busy && (
        <div className="h-2 w-full overflow-hidden rounded-full bg-panel">
          <div
            className="h-full bg-accent transition-all"
            style={{ width: `${stage === "saving" ? 100 : progress}%` }}
          />
        </div>
      )}
      {stage === "uploading" && <p className="text-sm text-mute">Uploading… {progress}%</p>}
      {stage === "saving" && <p className="text-sm text-mute">Saving details…</p>}
      {error && <p className="text-sm text-accent">{error}</p>}

      <button
        type="submit"
        disabled={busy}
        className="mt-2 rounded-lg bg-accent px-4 py-2 font-medium text-white hover:opacity-90 disabled:opacity-50"
      >
        {busy ? "Publishing…" : "Publish"}
      </button>
    </form>
  );
}
